#!/bin/bash

. ./unimelb-comp90024-2020-grp-48-openrc.sh; ansible-playbook -v --ask-become-pass playbook.yaml